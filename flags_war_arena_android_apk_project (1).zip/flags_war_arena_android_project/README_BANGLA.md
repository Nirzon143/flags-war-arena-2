# Flags War Arena — Android APK project

এটি V28 HTML game-কে Android WebView app হিসেবে প্যাকেজ করার Android Studio project।

## APK সরাসরি কেন এখানে তৈরি করা যায়নি
এই build environment-এ Android SDK / Android build-tools (`android.jar`, `aapt2`, `apksigner`) নেই। তাই এখানে installable APK compile/sign করা সম্ভব হয়নি। ভুল বা নকল APK দেওয়া হচ্ছে না।

## GitHub Actions দিয়ে APK তৈরি
1. এই ZIP extract করো।
2. পুরো folder একটি নতুন GitHub repository-তে upload করো।
3. GitHub repository → Actions → `Build Flags War Arena APK` → `Run workflow` চাপো।
4. Build সফল হলে workflow run-এর নিচে `flags-war-arena-debug-apk` artifact download করো।
5. ZIP extract করে `app-debug.apk` Android ফোনে install করো। প্রথমবার Android unknown-app install permission চাইতে পারে।

## Build configuration
- App: Flags War Arena
- Package: `com.flagswararena.app.debug` (debug build)
- Minimum Android: Android 6.0 (API 23)
- Target / Compile SDK: 35
- Portrait + immersive full-screen
- Game HTML এবং WAV soundtrack app assets-এর মধ্যে আছে।

## Voice announcement
- Android APK-তে Native Android Text-to-Speech ব্যবহার হয়; WebView-এর `speechSynthesis`-এর ওপর নির্ভর করে না।
- English (US) voice, সামান্য elevated pitch এবং natural voice preference সেট করা আছে। নির্দিষ্ট female voice পাওয়া যাবে কি না তা ফোনে ইনস্টল করা TTS engine/voice-এর ওপর নির্ভরশীল।
- ফোনে Settings → System → Languages & input → Text-to-speech output থেকে English voice download/নির্বাচন করে নাও।

## Network dependency
গেমের বর্তমান HTML Matter.js 0.20.0 এবং country flag images-এর জন্য CDN/FlagCDN ব্যবহার করে। তাই প্রথম চালনায় এবং পতাকা লোড করতে Internet connection প্রয়োজন। Soundtrack HTML-এর মধ্যে embedded; পাশাপাশি WAV asset-ও রাখা হয়েছে।
