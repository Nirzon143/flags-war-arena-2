package com.flagswararena.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.pm.ActivityInfo;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.util.Log;

import java.util.Locale;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends Activity {
    private WebView webView;
    private TextToSpeech textToSpeech;
    private boolean ttsReady = false;
    private String pendingText = null;
    private boolean pendingPriority = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        );

        textToSpeech = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int result = textToSpeech.setLanguage(Locale.US);
                textToSpeech.setSpeechRate(0.92f);
                textToSpeech.setPitch(1.08f);
                chooseNaturalVoice();
                textToSpeech.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String utteranceId) { }
                    @Override public void onDone(String utteranceId) { notifySpeechDone(); }
                    @Override public void onError(String utteranceId) { notifySpeechDone(); }
                    @Override public void onStop(String utteranceId, boolean interrupted) { notifySpeechDone(); }
                });
                ttsReady = result != TextToSpeech.LANG_MISSING_DATA
                    && result != TextToSpeech.LANG_NOT_SUPPORTED;
                if (ttsReady && pendingText != null) {
                    String text = pendingText;
                    boolean priority = pendingPriority;
                    pendingText = null;
                    speakNative(text, priority);
                }
            } else {
                Log.e("FlagsWarArena", "Android TextToSpeech initialization failed: " + status);
            }
        });

        webView = new WebView(this);
        webView.setBackgroundColor(0xFF070D1B);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setBlockNetworkImage(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        webView.addJavascriptInterface(new AndroidTtsBridge(), "AndroidTTS");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String scheme = request.getUrl().getScheme();
                return !("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme)
                    || "file".equalsIgnoreCase(scheme));
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage message) {
                Log.d("FlagsWarArena", message.message() + " -- line " + message.lineNumber());
                return true;
            }
        });

        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void chooseNaturalVoice() {
        if (textToSpeech == null) return;
        try {
            Set<Voice> voices = textToSpeech.getVoices();
            if (voices == null) return;
            Voice best = null;
            for (Voice voice : voices) {
                if (!voice.getLocale().getLanguage().equalsIgnoreCase("en")) continue;
                String name = voice.getName().toLowerCase(Locale.ROOT);
                if (name.contains("female") || name.contains("woman") || name.contains("samantha")
                    || name.contains("aria") || name.contains("jenny") || name.contains("zira")
                    || name.contains("susan") || name.contains("karen")) {
                    best = voice;
                    if (!voice.isNetworkConnectionRequired()) break;
                }
            }
            if (best != null) textToSpeech.setVoice(best);
        } catch (Exception e) {
            Log.w("FlagsWarArena", "Could not select preferred TTS voice", e);
        }
    }

    private void speakNative(String text, boolean priority) {
        if (!ttsReady || textToSpeech == null || text == null || text.trim().isEmpty()) return;
        if (priority) textToSpeech.stop();
        String utteranceId = "flags-war-" + UUID.randomUUID();
        textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId);
    }

    private void notifySpeechDone() {
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(
                "if(window.onNativeTtsDone)window.onNativeTtsDone();", null);
        });
    }

    private class AndroidTtsBridge {
        @JavascriptInterface
        public boolean speak(String text, boolean priority) {
            if (text == null || text.trim().isEmpty()) return false;
            if (!ttsReady) {
                // Keep at most one pending line; never create a queue/backlog.
                pendingText = text;
                pendingPriority = priority;
                return true;
            }
            runOnUiThread(() -> speakNative(text, priority));
            return true;
        }

        @JavascriptInterface
        public void stop() {
            runOnUiThread(() -> {
                if (textToSpeech != null) textToSpeech.stop();
                notifySpeechDone();
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onPause() {
        if (webView != null) webView.onPause();
        if (textToSpeech != null) textToSpeech.stop();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.loadUrl("about:blank");
            webView.destroy();
            webView = null;
        }
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
            textToSpeech = null;
        }
        super.onDestroy();
    }
}
